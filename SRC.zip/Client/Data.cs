﻿using System;
using System.Collections.Generic;

namespace MineService_Client
{
    public static class Data
    {
        public static Dictionary<String, ServerTabItem> serverTabs = new Dictionary<string, ServerTabItem>();
    }
}
