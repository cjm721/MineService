﻿namespace MineService_Server
{
    class MCServerConfig
    {
    }
}
